#include "HTStream.h"

extern HTStream * HTPipe PARAMS((char * script, HTStream * sink)); 
extern int HTLoadFileToStream PARAMS((int fd, HTStream* sink));
