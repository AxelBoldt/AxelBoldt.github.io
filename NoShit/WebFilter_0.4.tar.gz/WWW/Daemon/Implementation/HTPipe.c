
/*
**	P I P E  C L A S S
**
**	The pipe class pipes a stream through a script that is fed to the
**      shell.
**
**      How it works: we fork off the shell script and feed the stream
**      to its incoming pipe. Another forked off process (the
**      "sentinel") reads the script's output from its out pipe and 
**      stuffs it into the sink stream. Lot's of childs to care about.
**
**      Written by Axel Boldt (boldt@math.ucsb.edu) to implement as part 
**      of the NoShit extension.
*/

#include "HTPipe.h"

#include "HTLog.h"

#include "tcp.h"       /* takes care of types.h, fcntl.h, unistd.h, 
                          stat.h, wait.h, which are needed for open(),
                          read(), write(), fork() and wait().   */
#include <sys/wait.h>  /* for waitpid() */

#if 0
   #include <sys/types.h> /* for open(), read(), write() */
   #include <sys/stat.h>  /* for open() */
   #include <fcntl.h>     /* for open() */


   #include <unistd.h>    /* for fork(), read(), write() */
#endif

#include <signal.h>    /* for kill() */




#define PIPE_BUFFER_SIZE 4096


/*		Stream Object
**		------------
*/

struct _HTStream {
	CONST HTStreamClass *	isa;
	
	HTStream *		sink;
        int                     pipe;    /* the pipe where the script listens */
        int                     pids[2]; /* pids of the two child processes */
};


PRIVATE void HTPipe_put_character ARGS2(HTStream *, me, char, c)
{
    if (write ( me->pipe, &c, 1) < 0) 
      HTLog_error("HTPipe_put_character: write error to pipe.");
}

PRIVATE void HTPipe_put_string ARGS2(HTStream *, me, CONST char*, s)
{
    if (!s) {
      HTLog_error(
        "HTPipe_put_string: internal error: called with NULL pointer.");
      return;
    }
    while (*s) {
      if (write ( me->pipe, s, 1) < 0) {
        HTLog_error("HTPipe_put_string: write to pipe failed.");
        return;
      }
      s++;
    }
}

PRIVATE void HTPipe_write ARGS3(HTStream *, me, CONST char*, s, int, l)
{
    if (!s) {
      HTLog_error(
        "HTPipe_write: internal error: called with NULL pointer.");
      return;
    }
    if ( write ( me->pipe, s, l) < 0) {
        HTLog_error("HTPipe_write: write to pipe failed.");
        return;
      }
}

PRIVATE void HTPipe_free ARGS1(HTStream *, me)
{
  close(me->pipe);
  {  
    /* Now wait for me->pids; this code taken from HTScript.c and HTDaemon.c */
    
#if defined(NeXT) || defined(_AIX)
    union wait status;
#else
    int status;
#endif

#if ( defined(POSIXWAIT) || defined(__hpux)) && !defined(Mips)
#define USE_WAITPID
#endif

#ifdef USE_WAITPID
    waitpid(me->pids[0], &status, 0);
    CTRACE(stderr,"Filterscript terminated.\n");
    waitpid(me->pids[1], &status, 0);
    CTRACE(stderr,"Sentinel.... terminated.\n");
#else /* ! USE_WAITPID */
    wait4(me->pids[0],&status, 0, NULL);
    CTRACE(stderr,"Filterscript terminated.\n");
    wait4(me->pids[1],&status, 0, NULL);
    CTRACE(stderr,"Sentinel.... terminated.\n");
#endif /* USE_WAITPID */
  }
  (*me->sink->isa->_free)(me->sink);
  free(me);
}

PRIVATE void HTPipe_abort ARGS2(HTStream *, me, HTError, e)
{
  CTRACE(stderr,
     "HTPipe_abort: Sending TERM signal to filter script and waiting for it to do cleanup\n");
  /* Give the script a chance to terminate in orderly manner: */
  close(me->pipe);
  sleep(5);
  CTRACE(stderr, "HTPipe_abort: Sending KILL signal to script\n");
  kill(me->pids[0], SIGKILL); /* This one really kills it */
  CTRACE(stderr, "HTPipe_abort: Killing script sentinel\n");
  kill(me->pids[1], SIGKILL);
  /* No need to wait here, zombies will be dealt with elsewhere. */
  (*me->sink->isa->abort)(me->sink,e);
  free(me);
}


/*	Pipe stream
**	-----------
*/
PRIVATE CONST HTStreamClass HTPipeClass =
{		
	"Pipe",
	HTPipe_free,
	HTPipe_abort,
	HTPipe_put_character, 	
        HTPipe_put_string,
	HTPipe_write
}; 


/*	Pipe creation
**      returns NULL if error occurred.        
*/
PUBLIC HTStream * HTPipe ARGS2(char *, script, HTStream *, sink)
{
    HTStream * me = (HTStream*)malloc(sizeof(*me));
    int pin[2], pout[2], pids[2];

    if (!me) outofmem(__FILE__, "HTPipe");
    me->isa = &HTPipeClass;
    me->sink = sink;
    if(pipe(pin) < 0 || pipe(pout)<0) {
      HTLog_error("HTPipe: couldn't create pipe.");
      free(me);
      return NULL;
    }
    pids[0] = fork();
    if (pids[0] == -1) {
      HTLog_error("HTPipe: couldn't fork() the script.");
      free(me);
      return NULL;
    }
    else if (pids[0] == 0)
      {
        /* Child */
        close(pin[1]);
        close(pout[0]); 
        dup2(pin[0],0);
        close(pin[0]);
        /* stdout and stderr of script go to pipe */
        dup2(pout[1],1);
        dup2(pout[1],2);
        close(pout[1]);
        if (-1 == execlp("sh", "sh", "-c", script, NULL))
          HTLog_error("HTPipe: execlp() of script failed.");
        exit(0);
      }
    CTRACE(stderr, "HTPipe...... Filter script \"%s\" forked with pid %d.\n",script,pids[0]);
    close(pin[0]);
    close(pout[1]);
    me->pipe = pin[1];
    pids[1] = fork();
    if (pids[1] == -1)
      {
        HTLog_error("HTPipe: fork() of script sentinel failed.");
        CTRACE(stderr,
               "HTPipe...... Sending TERM signal to script %s and waiting for it to do cleanup\n",script);
        kill(pids[0], SIGTERM); /* Script may catch TERM signal to do cleanup */
        sleep(5);

        CTRACE(stderr, "HTPipe...... Sending KILL signal to script %s\n",script);
        kill(pids[0], SIGKILL); /* This one really kills it */
        free (me);
        return NULL;
      }
    else if (pids[1] == 0)
      {
        /* 2nd Child */
        close(pin[1]);
        HTLoadFileToStream(pout[0],sink);
        close(pout[0]);
        exit(0);
      }
    CTRACE(stderr,"HTPipe...... Sentinel for filter script forked with pid %d.\n",pids[1]);
    me->pids[0] = pids[0];
    me->pids[1] = pids[1];
    close(pout[0]);
    return me;
}

/*
** Load the contents of a file onto a stream. fd is assumed to be open
** for reading and will be closed at the end of HTLoadFileToStream.
** Returns 0 if succeeded and -1 if a read error occurred.
*/

PUBLIC int HTLoadFileToStream ARGS2(int, fd, HTStream *, sink)
{
  char input_buffer[PIPE_BUFFER_SIZE+2];
  
  
  for(;;) {
    int status = read(fd,input_buffer, PIPE_BUFFER_SIZE);

    if (status == 0)
      /* EOF */
      break;
    else if (status < 0) {
      /* Error */
      HTLog_error("HTLoadFileToStream: read error.");
      close(fd);
      return(-1);
    }
    (*sink->isa->put_block)(sink, input_buffer, status);
  }
  close(fd);
  return(0);
}
