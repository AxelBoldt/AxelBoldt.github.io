
/*								HTWild.h
 *	WILDCARD MATCHING MODULE
 *	* * * * * * * * * * * * *
 *
 * Author:
 *	Ari Luotonen, CERN, April 1994, <luotonen@dxcern.cern.ch>
 *
 * This interface contains the following functions:
 *
 *	HTPattern_new(str,is_template)
 *		returns an internal representation (HTPattern *) for
 *		a given a string.  This can be used when later comparing
 *		actual strings against templates.
 *		Asterisk * means any character.
 *		Any character can be escaped by preceding it with a
 *		backslash; at least * and \ must be escaped when they
 *		should be taken literally, but all other escapes are
 *		also understood.
 *		is_template must be YES if the pattern is to be used for 
 *		matching later (i.e. it does not appear as second argument 
 *		of Pass, Map, Redirect or Exec).
 *		If the global sc.regexp is true, then str can be an
 *		extended regexp as used by GNU grep; "^" will be
 *		prepended and "$" appended.
 *
 *	HTPattern_free(pat)
 *		frees the memory taken up by the pattern pat.
 *
 *	HTPattern_match(pat,eqv,act,wildstart)
 *		matches the actual string act against pattern pat.
 *		pat should have been created with
 *		HTPattern_new(...,YES) and eqv, if non-NULL, with 
 *		HTPattern_new(...,NO).
 *		If the pattern eqv is non-NULL the result returned
 *		will be a new string where the string is mapped to
 *		pattern eqv. In regexp mode, this means that a backslash
 *		followed by a digit in eqv is replaced by the string
 *		that matched the corresponding parenthesized 
 *		subexpression of pat. Backslash followed by something else
 *		is replaced by that something.
 *		Both pat and eqv should have been created using the same 
 *		setting of sc.regexp.
 *		If eqv is NULL, a copy of act is returned.
 *		If act doesn't match the pattern, NULL is returned.
 *		wildstart, if non-NULL, will point to a pointer to the 
 *		first character in the result that was matched by a 
 *		subexpression of pat, or to NULL if there is none.
 *		NOTE: /~ in the beginning must be explicitly matched, 
 *		unless we are using full regular expression matching.
 *
 *	HTPattern_url_match(pat,url)
 *		takes a pattern and a URL-escaped URL, and matches
 *		an unescaped version of URL against the pattern;
 *		returns YES on match, NO on mismatch.
 *
 *	The datatype HTPattern should be treated as an abstract datatype.
 */

#ifndef HTWILD_H
#define HTWILD_H

#include "HTUtils.h"

#ifdef NO_REGEX

typedef struct _HTPattern {
    BOOL   wild;
    char * text;
    struct _HTPattern * next;
} HTPattern;

#else /* regexp support */

#include "HTrx.h"

typedef struct _HTPattern {
    BOOL              is_regexp; /* if this is a full regexp as opposed to a */
                                 /* simple pattern. */
    regex_t *         compiled;  /* the compiled full regexp */
    BOOL                wild;    /* If wildcard before this text (used for */
                                 /* simple patterns only */
    char *              text;    /* For simple patterns: required text after */
                                 /* wildcard; also used to store the replace- */
                                 /* ment pattern for full regexps. */
    struct _HTPattern * next;    /* Next required text portion (simple */
                                 /* patterns only) */
} HTPattern;

#endif /* regexp support */

PUBLIC HTPattern * HTPattern_new PARAMS((CONST char * str, BOOL template));

PUBLIC char *	   HTPattern_match PARAMS((HTPattern *	pat,
					   HTPattern *	eqv,
					   CONST char *	act,
					   char ** wildstart));


PUBLIC void	   HTPattern_free PARAMS((HTPattern * pat));
PUBLIC BOOL HTPattern_url_match PARAMS((HTPattern *	pat,
					CONST char *	url));

#endif /* HTWILD_H */

