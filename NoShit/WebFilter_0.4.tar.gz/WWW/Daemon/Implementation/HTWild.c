
/*								HTWild.h
 *	WILDCARD MATCHING MODULE
 *	* * * * * * * * * * * * *
 *
 * Author:
 *	Ari Luotonen, CERN, April 1994, <luotonen@dxcern.cern.ch>
 *
 * IMPORTANT:
 *	Throughout this module we have to check HTRuleCaseSense to find
 *	out if matching should be made in a case-sensitive manner.
 *	In Unix it's always case-sensitive, but in VMS it usually
 *	(but not always) has to be case-insensitive (for security,
 *	e.g. Protect rules might not be matched if someone is fooling
 *	around with upper-case characters when the pattern is
 *	lower-case).
 */

#include "HTWild.h"
#include "HTParse.h"
#include "tcp.h"
#include "HTConfig.h"
#include "HTLog.h"

extern BOOL HTRuleCaseSense;

typedef struct _HTWildMatch {
    char *			text;
    struct _HTWildMatch *	next;
} HTWildMatch;


PRIVATE HTPattern * pat_new ARGS3(BOOL,		wild,
				  CONST char *,	text,
				  HTPattern *,	prev)
{
    HTPattern * p = (HTPattern*)calloc(1,sizeof(HTPattern));
    if (!p) outofmem(__FILE__, "HTPattern_new");

#ifndef NO_REGEX
    p->is_regexp = NO;
#endif

    p->wild = wild;
    if (text)
	StrAllocCopy(p->text,text);
    if (prev) prev->next = p;
    return p;
}


PUBLIC void HTPattern_free ARGS1(HTPattern *, p)
{
    HTPattern * killme;

    if (!p) return;
#ifndef NO_REGEX    
    if (p->is_regexp) {
      if (p->compiled) {
        regfree (p->compiled);
        free (p->compiled);
      };
      if (p->text) {
        free(p->text);
      }
      free (p);
    } else 
#endif
      while (p) {
	if (p->text) free(p->text);
	killme = p;
	p = p->next;
	free(killme);
      }
}

#ifndef NO_REGEX

/*
 *  Takes an error code as returned by regcomp and produces the
 *  corresponding error message. From the info pages to the GNU libc.
 */
PRIVATE char * get_regerror ARGS2(int, errcode, regex_t *, compiled)
{
  size_t length = regerror (errcode, compiled, NULL, 0);
  char *buffer = malloc (length);
  (void) regerror (errcode, compiled, buffer, length);
  return buffer;
}

#endif


PUBLIC HTPattern * HTPattern_new ARGS2(CONST char *, str, BOOL, is_template)
{
#ifndef NO_REGEX    
    if (sc.regexp) {
      HTPattern * result = (HTPattern*)calloc(1,sizeof(HTPattern));
      if (!result) outofmem(__FILE__, "HTPattern_new");
      result->is_regexp = YES;
      if (!is_template) {
        StrAllocCopy(result->text, str);
      } else {
        regex_t * compiled = (regex_t *)calloc(1,sizeof(regex_t));
        int error;
        char * tmp = NULL;

        if (!compiled) outofmem(__FILE__, "HTPattern_new");

        /* We anchor the regexp at the beginning and at the end: */
        StrAllocCat(tmp,"^");
        StrAllocCat(tmp,str);
        StrAllocCat(tmp,"$");
        error = regcomp ( compiled, tmp, REG_EXTENDED | 
                         ( HTRuleCaseSense ? 0 : REG_ICASE ));
        if (error) {
          char * errormsg = get_regerror(error, compiled);
          HTLog_error2("HTPattern_new: error in regexp ", tmp);
          HTLog_error2("HTPattern_new: regexp error message: ", errormsg);
          free(tmp);
          free(errormsg);
          regfree(compiled);
          free(compiled);
          free(result);
          return (NULL);
        }
        free(tmp);
        result->compiled = compiled;
      }
      return (result);
    } else 
#endif /* regexp support */
    {
      int len;
      CONST char * cur = str;
      char * buf = NULL;
      char * dest = NULL;
      HTPattern * head = NULL;
      HTPattern * tail = NULL;
      BOOL wild = NO;
      
      if (!str) return NULL;

      len = strlen(str);
      dest = buf = (char*)calloc(1,len+1);
      if (!buf) outofmem(__FILE__, "HTPattern_new");

      while (*cur) {
	if (*cur == '\\') {
	    cur++;
	    if (*cur)
		*dest = *cur;
	    else {
		*dest++ = '\n';
		break;
	    }
	}
	else if (*cur == '*') {
	    *dest = 0;
	    if (*buf) {
		tail = pat_new(wild,buf,tail);
		if (!head) head = tail;
	    }
	    dest = buf;
	    cur++;
	    wild = YES;
	    continue;
	}
	else {
	    *dest = *cur;
	}
	dest++;
	cur++;
      }
      *dest = 0;
      if (wild || *buf) {
	tail = pat_new(wild,buf,tail);
	if (!head) head = tail;
      }
      free(buf);
      return head;
    }
}


PRIVATE void HTWildMatch_free ARGS1(HTWildMatch *, w)
{
    HTWildMatch * killme;

    while (w) {
	if (w->text) free(w->text);
	killme = w;
	w = w->next;
	free(killme);
    }
}


PRIVATE char * replace ARGS2(HTPattern *,	eqv,
			     HTWildMatch *,	matches)
{
    int len = 1;
    char * ret = NULL;
    char * cur = NULL;
    HTPattern * t = eqv;
    HTWildMatch * w = matches;

    while (t) {
	if (t->wild && w) {
	    if (w->text) len += strlen(w->text);
	    w = w->next;
	}
	if (t->text) len += strlen(t->text);
	t = t->next;
    }

    cur = ret = (char*)calloc(1,len);
    if (!ret) outofmem(__FILE__, "replace");

    t = eqv;
    w = matches;

    while (t) {
	if (t->wild && w) {
	    if (w->text) {
		strcpy(cur,w->text);
		cur += strlen(w->text);
	    }
	    w = w->next;
	}
	if (t->text) {
	    strcpy(cur,t->text);
	    cur += strlen(t->text);
	}
	t = t->next;
    }

    return ret;
}


PRIVATE HTWildMatch * HTWildMatch_new ARGS1(CONST char *, text)
{
    HTWildMatch * w = (HTWildMatch*)calloc(1,sizeof(HTWildMatch));
    if (!w) outofmem(__FILE__, "match");

    if (text) StrAllocCopy(w->text,text);
    return w;
}


PRIVATE BOOL is_user_dir ARGS1(CONST char *, str)
{
    if (!strncmp(str,"/~",2) || !strncmp(str,"file:/~",7))
	return YES;
    else
	return NO;
}


PRIVATE HTWildMatch * match ARGS2(HTPattern *,	pat,
				  CONST char *,	act)
{
    BOOL udir;

    if (!pat || !act) {
	if ((!pat && act && *act)  ||  (pat && !act))
	    return NULL;
	else
	    return HTWildMatch_new(NULL);
    }

    udir = is_user_dir(act);

    if (!pat->wild) {		/* No wildcard before string pattern */
	if (pat->text) {	/* String pattern given, just compare it */
	    int len = strlen(pat->text);
	    if (((HTRuleCaseSense && strncmp(pat->text,act,len) != 0) ||
		 (!HTRuleCaseSense && strncasecomp(pat->text,act,len) != 0))
		||  /* No match or not     */
		(udir && !is_user_dir(pat->text)))  /* explicitly user dir */
		return NULL;	/* No match */
	    else				 /* Strings match...	  */
		return match(pat->next,act+len); /* ...but does the rest? */
	}
	else {	/* No wild nor text */
	    if (!*act)
		return HTWildMatch_new(NULL);	/* String ended -- ok */
	    else
		return NULL;			/* No match */
	}
    }
    else {			/* Wildcard before string pattern */
	if ((!pat->text || !*pat->text) && !udir)  /* No string required... */
	    return HTWildMatch_new(act);	   /* ...anything matches.  */
	else if (udir && !is_user_dir(pat->text))
	    return NULL;		/* User dir not explicitly matched */
	else {
	    int len = strlen(pat->text);
	    char * cur = HTRuleCaseSense
		? strstr((char*)act,pat->text)
		: strcasestr((char*)act,pat->text);

	    while (cur) {
		HTWildMatch * m = match(pat->next,cur+len);
		HTWildMatch * w = NULL;

		if (m) {
		    char saved = *cur;
		    *cur = 0;
		    w = HTWildMatch_new(act);
		    *cur = saved;
		    w->next = m;
		    return w;
		}
		if (HTRuleCaseSense)
		    cur = strstr(cur+len,pat->text);
		else
		    cur = strcasestr(cur+len,pat->text);
	    }
	    return NULL;	/* Required string not found */
	}
    }

    /* Never reached, but stupid compilers warn without this: */
    return NULL;
}


void print_pat ARGS1(HTPattern *, p)
{
    fprintf(stderr, "\nGot pattern:\n");
    while (p) {
	if (p->wild)
	    fprintf(stderr, "  *");
	if (p->text)
	    fprintf(stderr, "  \"%s\"", p->text);
	p = p->next;
    }
    fprintf(stderr, "\n\n");
}

#ifndef NO_REGEX

PRIVATE char *replace_regexp ARGS5(char *, eqv, CONST char *, orig, 
                                   int, nmatches, regmatch_t *, matches,
                                   char **, wildstart)
{
  char * result;
  char * orig_copy = NULL;
  char * p1;
  char * p2;
  char letter;
  int i;
  int wildstartpos = -1;

  StrAllocCopy(orig_copy,orig);
  result = NULL;
  p2 = eqv;

  for (p1 = eqv; *p1; p1++) {
    if (*p1 == '\\') {
      *p1 = '\0';
      StrAllocCat(result,p2);
      *p1 = '\\';
      p1++;
      if isdigit (*p1) {
        p2 = p1 + 1;
        if (((i = *p1 - '0') <= nmatches ) && ( matches[i].rm_eo != -1 ) ) {
          letter = orig_copy[matches[i].rm_eo];
          if (wildstartpos == -1) {
            wildstartpos = strlen(result);
          }
          orig_copy[matches[i].rm_eo] = '\0';
          StrAllocCat(result,orig_copy + matches[i].rm_so);
          orig_copy[matches[i].rm_eo] = letter;
        }
      } else {
        p2 = p1;
      }
    }
  }
  StrAllocCat(result,p2);
  if (wildstart) {
    if (wildstartpos == -1) {
      *wildstart = NULL;
    } else {
      *wildstart = result + wildstartpos;
    }
  }
                   
  free(orig_copy);
  return result;
}

#endif /* regexp support */


PUBLIC char * HTPattern_match ARGS4(HTPattern *,	pat,
				    HTPattern *,	eqv,
				    CONST char *,	act,
                                    char **, wildstart)
     
{
  char * result = NULL;

  if (!pat || !act) return NULL;

#ifndef NO_REGEX

  if (pat->is_regexp) {

    /* Is eqv of the right type? */ 
    if (eqv && ((!eqv->is_regexp) || eqv->compiled)) {
      HTLog_error("HTPattern_match: arguments are of different types");
      return NULL;
    } else {

      int nmatches = pat->compiled->re_nsub;
      regmatch_t * matches = malloc((nmatches+1) * sizeof(regmatch_t));
      int error;
      if (!matches) outofmem(__FILE__, "HTPattern_match");
    
      error = regexec (pat->compiled,act,nmatches+1,matches,0);
      if (!error) {
        if (eqv) {
          result = replace_regexp(eqv->text,act,nmatches,matches,wildstart);
        } else {
          StrAllocCopy(result, act);
          if (wildstart) {
            if (nmatches == 0) {
              *wildstart = NULL;
            } else {
              *wildstart = result + matches[1].rm_so;
            }
          }
        }
      } else if (error == REG_NOMATCH) {
        result = NULL;
      } else {
        char * error_msg = get_regerror(error, pat->compiled);
        HTLog_error2("HTPattern_match: while trying to match: ", act);
        HTLog_error2("HTPattern_match: regexp error message: ",error_msg);
        free(error_msg);
        result = NULL;
      }
      free (matches);
    }
  } else if (eqv && eqv->is_regexp) {
      HTLog_error("HTPattern_match: arguments are of different types");
      return NULL;
  } else
#endif /* regexp support */
  {
      HTWildMatch * matches = NULL;

      matches = match(pat,act);
      if (!matches) return NULL;

      if (eqv) {
	result = replace(eqv,matches);
        if (wildstart) {
          if (eqv->wild) {
            *wildstart = result;
          } else if (eqv->text && eqv->next) {
            *wildstart = result + strlen(eqv->text);
          } else {
            *wildstart = NULL;
          }
        }
      } else {
	StrAllocCopy(result,act);
        if (wildstart) {
          if (pat->wild) {
            *wildstart = result;
          } else if (pat->text && pat->next) {
            *wildstart = result + strlen(pat->text);
          } else {
            *wildstart = NULL;
          }
        }
      }
      HTWildMatch_free(matches);
  }
  return result;
}


PUBLIC BOOL HTPattern_url_match ARGS2(HTPattern *,	pat,
				      CONST char *,	url)
{
    char * match;
    char * decoded = NULL;

    StrAllocCopy(decoded,url);
    HTUnEscape(decoded);

    match = HTPattern_match(pat,NULL,decoded,NULL);

    free(decoded);
    if (match) {
	free(match);
	return YES;
    }
    return NO;
}

#ifdef TEST_MAIN

PUBLIC int main ARGS2(int,	argc,
		      char **,	argv)
{
    HTPattern * pat = NULL;
    HTPattern * eqv = NULL;
    char * act = NULL;
    char * res = NULL;

    if (argc < 3 || argc > 4) {
	fprintf(stderr,
		"\nMATCH TESTER: Usage:\n\t%s template [equiv] actual\n\n",
		argv[0]);
	exit(1);
    }

    pat = HTPattern_new(argv[1], YES);
    print_pat(pat);
    if (argc == 4) {
	eqv = HTPattern_new(argv[2], NO);
	print_pat(eqv);
	act = argv[3];
    }
    else {
	act = argv[2];
    }


    res = HTPattern_match(pat,eqv,act,NULL);
    if (res)
	printf("%s\n",res);
    else
	printf("No match.\n");

    HTPattern_free(pat);
    if (eqv) HTPattern_free(eqv);
}
#endif /* TEST_MAIN */

